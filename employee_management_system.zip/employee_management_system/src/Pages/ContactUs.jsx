import React from 'react'

const ContactUs = () => {
  return (
    <div>
      contactus
    </div>
  )
}

export default ContactUs
