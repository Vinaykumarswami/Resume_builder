import React from "react";
import "./global.css";
import { RouterProvider } from "react-router-dom";
import myRoutes from "./Routes/myRoutes";
import NavMainContainer from "./Components/NavbarComponents1/NavMainContainer";

function App() {
  return (
    <>
      <h1 className="bg-amber-200">App</h1>
      <NavMainContainer />
       <RouterProvider router={myRoutes} />

    </>
  );
}

export default App;
