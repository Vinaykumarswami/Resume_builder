import React from "react";
import { createBrowserRouter } from "react-router-dom";
import MainLayouts from "../Layouts/MainLayouts";
import Home from "../Pages/Home";
import ContactUs from "../Pages/ContactUs";
import Services from "../Pages/Services";
import Register from "../AuthComponent/Register";
import Login from "../AuthComponent/Login"
import ResetPassword from "../AuthComponent/ResetPassword";

let myRoutes=createBrowserRouter([
    {
        path:"/",
        element:<MainLayouts/>,
        children:[
            {
                index:true,
                element:<Home/>

            },
            {
                path:"/contact",
                element:<ContactUs/>
            },
            {
                path:"/services",
                element:<Services/>

            },
            {
                path:"/register",
                element:<Register/>
            },
            {
                path:"/login",
                element:<Login/>
            },
            {
                path:"/resetpassword",
                element:<ResetPassword/>
            }
        ],

    },
]);

export default myRoutes;